#ifndef BOOL
#define BOOL
typedef enum {FALSE, TRUE} BOOLEAN;
#endif

