/* intArrayList.c */
#include "arrayList.h"
#include <assert.h>
#include <stdlib.h>

void ListMake(struct int_list * list)
{
  /* assuming that list is a valid pointer */
  assert(list != NULL);
  /* Nothing much to be done here for this particular
   * implementation of a list. Merely setting the
   * ''size'' member of the struct int_list object to 0 would
   * suffice.
   *
   * This interface routine exists because it is
   * anticipated that other implementations of a
   * list may need to do some initialisation before
   * the list can be manipulated.
   *
   */
}

BOOLEAN ListInsert(struct int_list * list, int num)
{
  /* any required local vars go here */
  assert(list != NULL);
  /* if the list is already full then indicate
   * insertion failure with a return value
   *
   * Check to see how this function was used in
   * main() to determine what value to return
   * for a FAILURE
   */
  /*
   * Here you'll need to write some code to
   * search for the correct place within the
   * array to insert the new element.
   * Finally return a value indicating SUCCESS
   *
   */
   /* dummy return value until you implement the function - it won't 
    * generate a warning that way
    */
   return FALSE;
}
void ListDisplay(struct int_list* pil)
{
  /* any required local vars go here */
  assert(pil != NULL);
  /* loop through all existing elements within
   * the array and display them one per line
   */
}
void ListFree(struct int_list * pil)
{
  assert(pil != NULL);
  /* Nothing much to be done here for this particular
   * implementation of a list. Merely setting the
   * size attribute to 0 would suffice
   */
}
